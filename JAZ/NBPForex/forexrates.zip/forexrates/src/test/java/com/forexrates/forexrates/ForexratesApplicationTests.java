package com.forexrates.forexrates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForexratesApplicationTests {

	@Test
	void contextLoads() {
	}

}
