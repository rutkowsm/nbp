package com.forexrates.forexrates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForexratesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForexratesApplication.class, args);
	}

}
